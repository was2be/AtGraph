#!/usr/bin/env python3
"""@Cam bridge for ToupTek cameras (and cameras made by ToupTek under other
names), through ToupTek's own SDK, natively on Apple Silicon and Intel Macs.

    python3 atcam_toupcam_bridge.py --sdk ~/Downloads/toupcamsdk
    python3 atcam_toupcam_bridge.py --sdk ~/Downloads/toupcamsdk --list
    python3 atcam_toupcam_bridge.py --sdk … --camera "sn:ZP2502…" --port 48621

The SDK is ToupTek's (download it from ToupTek; it is not part of this kit).
--sdk is the SDK folder as downloaded (with python/toupcam.py and
mac/libtoupcam.dylib), or any folder holding toupcam.py and libtoupcam.dylib
side by side; without --sdk, the folder named by TOUPCAM_SDK, this script's
folder and ~/Downloads/toupcamsdk are tried. Needs atcam_bridge.py (this
kit) beside it, and Python 3.9 or later; numpy is not needed.

What @Cam gets: the camera's raw sensor values (Mono or Bayer, 8 bits or
the sensor's full depth up to 16), or the camera's own processed color
(RGB8), with exposure (and auto exposure), gain, black level, resolution,
binning, region of interest, flips, software and external trigger,
conversion gain, the sensor temperature and, on cooled models, the cooler
and fan. Controls with standard names appear in @Cam's Camera, Image and
Trigger tabs; the rest are in the All Settings tab.
"""

import argparse
import ctypes
import importlib.util
import os
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from atcam_bridge import Camera, Feature, serve, DEFAULT_PORT   # noqa: E402

VERSION = "atcam_toupcam_bridge.py 1.0"


# ---------------------------------------------------------------- loading the SDK

def load_toupcam(sdk=None):
    """ToupTek's toupcam module, with its library found wherever the SDK is.
    toupcam.py looks for libtoupcam.dylib beside itself; in the SDK as
    downloaded they are in python/ and mac/, so the module is loaded as if
    it were in mac/."""
    candidates = [sdk, os.environ.get("TOUPCAM_SDK"), os.path.dirname(os.path.abspath(__file__)),
                  os.path.expanduser("~/Downloads/toupcamsdk")]
    for root in [os.path.expanduser(c) for c in candidates if c]:
        for py, lib in [(os.path.join(root, "toupcam.py"), os.path.join(root, "libtoupcam.dylib")),
                        (os.path.join(root, "python", "toupcam.py"), os.path.join(root, "mac", "libtoupcam.dylib"))]:
            if os.path.isfile(py) and os.path.isfile(lib):
                spec = importlib.util.spec_from_file_location("toupcam", py)
                module = importlib.util.module_from_spec(spec)
                # toupcam.py loads the library from the folder of its __file__.
                module.__file__ = os.path.join(os.path.dirname(lib), "toupcam.py")
                sys.modules["toupcam"] = module
                spec.loader.exec_module(module)
                module.__file__ = os.path.join(os.path.dirname(lib), "toupcam.py")
                return module, lib
    raise SystemExit("ToupTek's SDK wasn't found. Download it from ToupTek, then run this with "
                     "--sdk and the SDK's folder (the one with python/toupcam.py and mac/libtoupcam.dylib).")


def quarantine_hint(lib):
    return ("macOS may have refused ToupTek's library because it came from the internet. "
            "If so, run this once in Terminal, then try again:\n"
            f'    xattr -d com.apple.quarantine "{lib}"')


# ---------------------------------------------------------------- the camera

# A Bayer arrangement (as ToupTek names it, rows top to bottom) → GenICam's name.
BAYER = {"RGGB": "BayerRG", "GRBG": "BayerGR", "GBRG": "BayerGB", "BGGR": "BayerBG"}
# The containers the bridge protocol has, for a sensor's bit depth.
MONO_DEPTHS = [8, 10, 12, 14, 16]
BAYER_DEPTHS = [8, 10, 12, 16]


def container(bits, depths):
    """The smallest listed depth that holds `bits` (11 → 12; a Bayer 14 → 16)."""
    return next((d for d in depths if d >= bits), depths[-1])


class ToupTekCamera(Camera):
    vendor = "ToupTek"

    def __init__(self, tc, device):
        super().__init__()
        self.tc = tc
        self.device = device
        m = device.model
        self.flags = m.flag
        self.name = device.displayname or m.name
        self.model = m.name
        self.mono = bool(self.flags & tc.TOUPCAM_FLAG_MONO)
        self.resolutions = [(r.width, r.height) for r in m.res[:m.preview]] or [(r.width, r.height) for r in m.res]
        self._lock = threading.Lock()
        self._frame_ready = threading.Condition(self._lock)
        self._frame = None
        self._running = False
        self._wanted = False
        self._buffer = None
        self.h = None
        self._open()
        self._build()
        self._watcher = threading.Thread(target=self._watch, daemon=True)
        self._watcher.start()

    # ---- opening, and coming back after being unplugged

    def _open(self):
        self.h = self.tc.Toupcam.Open(self.device.id)
        if not self.h:
            raise SystemExit(f"Couldn't open {self.name}. Is another program (ToupView, say) using it?")
        try:
            self.serial = self.h.get_SerialNumber() if hasattr(self.h, "get_SerialNumber") else ""
        except Exception:
            self.serial = ""
        # Raw sensor values by default: what @Cam's measurements want.
        self._try(self.h.put_Option, self.tc.TOUPCAM_OPTION_RAW, 0 if self._rgb_mode() else 1)
        self._try(self.h.put_Option, self.tc.TOUPCAM_OPTION_BYTEORDER, 0)      # RGB, not BGR
        self._try(self.h.put_Option, self.tc.TOUPCAM_OPTION_UPSIDE_DOWN, 0)    # rows top to bottom

    def _watch(self):
        # Unplugged: wait for the camera to come back, then reopen it with the settings it had.
        while True:
            time.sleep(2)
            if not self.gone:
                continue
            try:
                devices = self.tc.Toupcam.EnumV2()
            except Exception:
                continue
            same = next((d for d in devices if d.id == self.device.id or d.displayname == self.device.displayname), None)
            if same is None:
                continue
            try:
                self.device = same
                self._open()
                self._apply_all()
                self.gone = False
                print(f"[{time.strftime('%H:%M:%S')}] {self.name} is back", flush=True)
            except (SystemExit, Exception):
                pass

    def _apply_all(self):
        # After reopening: the settings @Cam last saw, in an order that works.
        for name in ["PixelFormat", "Resolution", "BinningHorizontal", "ReverseX", "ReverseY", "ExposureAuto",
                     "ExposureTime", "Gain", "BlackLevel", "ConversionGain", "TriggerMode"]:
            f = self.feature(name)
            if f is not None and f.available and f.on_set and f.value is not None:
                try:
                    f.on_set(f.value)
                except Exception:
                    pass

    @staticmethod
    def _try(fn, *args, default=None):
        try:
            r = fn(*args)
            return default if r is None and default is not None else r
        except Exception:
            return default

    def _option(self, opt, default=None):
        return self._try(self.h.get_Option, opt, default=default)

    def _rgb_mode(self):
        f = self.feature("PixelFormat") if self._by_name else None
        return f is not None and f.value == "RGB8"

    # ---- the controls

    def _build(self):
        tc, h, flags = self.tc, self.h, self.flags
        F = Feature
        # Formats: raw at 8 bits, raw at each deeper sensor depth the camera
        # offers, and (color) the camera's own processed RGB.
        depths = [8]
        for flag, bits in [(tc.TOUPCAM_FLAG_RAW10, 10), (getattr(tc, "TOUPCAM_FLAG_RAW11", 0), 11),
                           (tc.TOUPCAM_FLAG_RAW12, 12), (tc.TOUPCAM_FLAG_RAW14, 14), (tc.TOUPCAM_FLAG_RAW16, 16)]:
            if flag and flags & flag:
                depths.append(bits)
        self._depths = depths
        self.add(F("BayerPattern", "enum", "From the camera", label="Bayer pattern", category="Image Format",
                   entries=["From the camera", "RG", "GR", "GB", "BG"], available=not self.mono, on_set=self._set_bayer,
                   tooltip="Which corner of the sensor is red, green or blue. Leave it to the camera unless the colors come out swapped."))
        formats = [self._format_name(b) for b in depths] + ([] if self.mono else ["RGB8"])
        self.add(F("PixelFormat", "enum", formats[-1 if self.mono else len(depths) - 1], label="Pixel format",
                   category="Image Format", entries=formats, on_set=self._set_format,
                   tooltip="Raw: the sensor's own values, for measuring. RGB8: the camera's processed color."))
        self.add(F("Resolution", "enum", self._res_name(0), label="Resolution", category="Image Format",
                   entries=[self._res_name(i) for i in range(len(self.resolutions))], on_set=self._set_resolution))
        bins = self._binnings()
        if len(bins) > 1:
            self.add(F("BinningHorizontal", "int", 1, label="Binning", category="Image Format", min=1, max=max(bins),
                       on_set=self._set_binning, tooltip="Averages n × n pixels into one (the bit depth stays)."))
            self.add(F("BinningVertical", "int", 1, label="Binning (vertical)", category="Image Format",
                       writable=False, on_get=lambda: self.feature("BinningHorizontal").value))
        self.add(F("Width", "int", 0, label="Width", category="Image Format", min=8, step=2,
                   on_set=lambda v: self._set_roi(width=v), on_get=lambda: self._roi()[2]))
        self.add(F("Height", "int", 0, label="Height", category="Image Format", min=8, step=2,
                   on_set=lambda v: self._set_roi(height=v), on_get=lambda: self._roi()[3]))
        self.add(F("OffsetX", "int", 0, label="Offset X", category="Image Format", min=0, step=2,
                   on_set=lambda v: self._set_roi(x=v), on_get=lambda: self._roi()[0]))
        self.add(F("OffsetY", "int", 0, label="Offset Y", category="Image Format", min=0, step=2,
                   on_set=lambda v: self._set_roi(y=v), on_get=lambda: self._roi()[1]))
        self._update_roi_ranges()
        if self.device.model.xpixsz > 0:
            self.add(F("SensorPixelWidth", "float", float(self.device.model.xpixsz), label="Sensor pixel width",
                       category="Device", unit="um", writable=False))
            self.add(F("SensorPixelHeight", "float", float(self.device.model.ypixsz), label="Sensor pixel height",
                       category="Device", unit="um", writable=False))
        self.add(F("ReverseX", "bool", False, label="Flip horizontally", category="Image Format",
                   on_set=lambda v: (h.put_HFlip(1 if v else 0), v)[1]))
        self.add(F("ReverseY", "bool", False, label="Flip vertically", category="Image Format",
                   on_set=lambda v: (h.put_VFlip(1 if v else 0), v)[1]))

        # Exposure and gain.
        lo, hi, _ = self._try(h.get_ExpTimeRange, default=(100, 1_000_000, 0))
        self.add(F("ExposureAuto", "enum", "Off", label="Auto exposure", category="Exposure",
                   entries=["Off", "Continuous"], on_set=self._set_auto_exposure))
        self.add(F("ExposureTime", "float", float(self._try(h.get_ExpoTime, default=10000)), label="Exposure time",
                   category="Exposure", unit="us", min=float(lo), max=float(hi), log=True,
                   on_set=lambda v: (h.put_ExpoTime(int(round(v))), float(h.get_ExpoTime()))[1],
                   on_get=lambda: float(self._try(h.get_ExpoTime, default=0))))
        glo, ghi, _ = self._try(h.get_ExpoAGainRange, default=(100, 100, 100))
        if ghi > glo:
            # ToupTek's gain is a percentage (100 = 1×); @Cam shows Gain as × .
            self.add(F("Gain", "float", self._try(h.get_ExpoAGain, default=100) / 100, label="Gain", category="Exposure",
                       unit="x", min=glo / 100, max=ghi / 100,
                       on_set=lambda v: (h.put_ExpoAGain(int(round(v * 100))), h.get_ExpoAGain() / 100)[1],
                       on_get=lambda: self._try(h.get_ExpoAGain, default=100) / 100))
        if flags & tc.TOUPCAM_FLAG_BLACKLEVEL:
            self.add(F("BlackLevel", "int", self._option(tc.TOUPCAM_OPTION_BLACKLEVEL, 0), label="Black level",
                       category="Exposure", min=0, max=self._black_max(),
                       on_set=lambda v: self._set_option(tc.TOUPCAM_OPTION_BLACKLEVEL, v),
                       on_get=lambda: self._option(tc.TOUPCAM_OPTION_BLACKLEVEL, 0)))
        if flags & tc.TOUPCAM_FLAG_CG:
            entries = ["Low", "High"] + (["HDR"] if flags & tc.TOUPCAM_FLAG_CGHDR else [])
            self.add(F("ConversionGain", "enum", entries[self._option(tc.TOUPCAM_OPTION_CG, 0) or 0], label="Conversion gain",
                       category="Exposure", entries=entries,
                       on_set=lambda v: (self._set_option(tc.TOUPCAM_OPTION_CG, entries.index(v)), v)[1],
                       tooltip="High: less read noise for dim samples; Low: more full well for bright ones."))
        if flags & tc.TOUPCAM_FLAG_PRECISE_FRAMERATE:
            fmax = (self._option(tc.TOUPCAM_OPTION_MAX_PRECISE_FRAMERATE, 0) or 0) / 10
            fmin = (self._option(getattr(tc, "TOUPCAM_OPTION_MIN_PRECISE_FRAMERATE", 0), 10) or 10) / 10
            if fmax > 0:
                self.add(F("AcquisitionFrameRate", "float", fmax, label="Frame rate", category="Acquisition", unit="Hz",
                           min=max(fmin, 0.1), max=fmax,
                           on_set=lambda v: (self._set_option(tc.TOUPCAM_OPTION_PRECISE_FRAMERATE, int(round(v * 10))),
                                             (self._option(tc.TOUPCAM_OPTION_PRECISE_FRAMERATE, 0) or 0) / 10)[1]))
        if self.device.model.maxspeed > 0:
            self.add(F("Speed", "int", self._try(h.get_Speed, default=0), label="USB speed", category="Acquisition",
                       min=0, max=self.device.model.maxspeed,
                       on_set=lambda v: (h.put_Speed(int(v)), h.get_Speed())[1],
                       tooltip="Lower it if frames drop on a busy USB bus or a long cable."))

        # Trigger.
        sources = (["Software"] if flags & tc.TOUPCAM_FLAG_TRIGGER_SOFTWARE else []) \
            + (["Line0"] if flags & tc.TOUPCAM_FLAG_TRIGGER_EXTERNAL else [])
        if sources:
            self.add(F("TriggerMode", "enum", "Off", label="Trigger mode", category="Trigger", entries=["Off", "On"],
                       on_set=lambda v: self._set_trigger(mode=v)))
            self.add(F("TriggerSource", "enum", sources[0], label="Trigger source", category="Trigger", entries=sources,
                       on_set=lambda v: self._set_trigger(source=v)))
            self.add(F("TriggerSoftware", "command", label="Software trigger", category="Trigger", available=False))

        # Temperature and cooling.
        if flags & tc.TOUPCAM_FLAG_GETTEMPERATURE:
            self.add(F("DeviceTemperature", "float", 0.0, label="Sensor temperature", category="Device", unit="C",
                       writable=False, on_get=lambda: self._try(h.get_Temperature, default=0) / 10))
        if flags & tc.TOUPCAM_FLAG_TEC_ONOFF:
            self.add(F("Cooler", "bool", bool(self._option(tc.TOUPCAM_OPTION_TEC, 0)), label="Cooler", category="Cooling",
                       on_set=lambda v: (self._set_option(tc.TOUPCAM_OPTION_TEC, 1 if v else 0), v)[1]))
            r = self._option(tc.TOUPCAM_OPTION_TECTARGET_RANGE, None)
            tmin, tmax = ((ctypes.c_short(r & 0xFFFF).value / 10, ctypes.c_short((r >> 16) & 0xFFFF).value / 10)
                          if r else (-50.0, 40.0))
            self.add(F("CoolerTargetTemperature", "float", (self._option(tc.TOUPCAM_OPTION_TECTARGET, 0) or 0) / 10,
                       label="Cooler target", category="Cooling", unit="C", min=tmin, max=tmax,
                       on_set=lambda v: (self._set_option(tc.TOUPCAM_OPTION_TECTARGET, int(round(v * 10))),
                                         (self._option(tc.TOUPCAM_OPTION_TECTARGET, 0) or 0) / 10)[1]))
        if flags & tc.TOUPCAM_FLAG_FAN and self.device.model.maxfanspeed > 0:
            self.add(F("FanSpeed", "int", self._option(tc.TOUPCAM_OPTION_FAN, 1) or 0, label="Fan speed", category="Cooling",
                       min=0, max=self.device.model.maxfanspeed,
                       on_set=lambda v: self._set_option(tc.TOUPCAM_OPTION_FAN, int(v))))

        # The camera's processed color only: its white balance.
        self.add(F("WhiteBalanceOnce", "command", label="White balance once", category="Color",
                   available=self._rgb_mode() and not self.mono))
        # Start in the format announced: the sensor's full depth, raw.
        pf = self.feature("PixelFormat")
        pf.value = self._set_format(pf.value)

    def _set_bayer(self, value):
        # The raw formats are named by the pattern: rename them, keeping the depth chosen.
        pf = self.feature("PixelFormat")
        depth = next((b for b in self._depths if self._format_name(b) == pf.value), None)
        self.feature("BayerPattern").value = value
        pf.entries = [self._format_name(b) for b in self._depths] + ([] if self.mono else ["RGB8"])
        if depth is not None:
            pf.value = self._format_name(depth)
            self._fmt = pf.value
        return value

    def _format_name(self, bits):
        if self.mono:
            return f"Mono{container(bits, MONO_DEPTHS)}"
        return f"{self._bayer_prefix()}{container(bits, BAYER_DEPTHS)}"

    def _bayer_prefix(self):
        f = self.feature("BayerPattern")
        if f is not None and f.value != "From the camera":
            return "Bayer" + f.value
        fourcc, _ = self._try(self.h.get_RawFormat, default=(0, 8))
        code = bytes([(fourcc >> s) & 0xFF for s in (0, 8, 16, 24)]).decode("ascii", "replace")
        return BAYER.get(code, "BayerRG")

    def _res_name(self, i):
        w, hgt = self.resolutions[i]
        return f"{w} × {hgt}"

    def _binnings(self):
        out = [1]
        try:
            for i in range(self.h.get_BinningNumber()):
                v = self.h.get_BinningValue(i)
                n = int("".join(c for c in str(v).split("x")[0] if c.isdigit()) or 0)
                if n > 1:
                    out.append(n)
        except Exception:
            pass
        return sorted(set(out))

    def _black_max(self):
        bits = self._sensor_bits()
        return {8: 31, 10: 124, 11: 248, 12: 496, 14: 1984, 16: 7936}.get(bits, 31)

    def _sensor_bits(self):
        _, bits = self._try(self.h.get_RawFormat, default=(0, 8))
        return bits or 8

    # ---- changes that need the camera stopped

    def _while_stopped(self, change):
        running = self._running
        if running:
            self._stop_sdk()
        try:
            return change()
        finally:
            if running:
                self._start_sdk()
            self._update_roi_ranges()

    def _set_option(self, opt, value):
        self.h.put_Option(opt, int(value))
        return value

    def _set_format(self, value):
        tc = self.tc
        self._wide = None     # whether deep values fill 16 bits: seen in the first frames
        self._seen = 0

        def change():
            # The format the frames are in from the restart on (the feature
            # itself takes the value only when this returns).
            self._fmt = value
            if value == "RGB8":
                self.h.put_Option(tc.TOUPCAM_OPTION_RAW, 0)
                self.h.put_Option(tc.TOUPCAM_OPTION_BITDEPTH, 0)
                self._try(self.h.put_Option, tc.TOUPCAM_OPTION_RGB, 0)
            else:
                bits = next(b for b in self._depths if self._format_name(b) == value)
                self.h.put_Option(tc.TOUPCAM_OPTION_RAW, 1)
                self.h.put_Option(tc.TOUPCAM_OPTION_BITDEPTH, 0 if bits == 8 else 1)
                pf = {8: "RAW8", 10: "RAW10", 11: "RAW11", 12: "RAW12", 14: "RAW14", 16: "RAW16"}[bits]
                self._try(self.h.put_Option, tc.TOUPCAM_OPTION_PIXEL_FORMAT, getattr(tc, "TOUPCAM_PIXELFORMAT_" + pf))
            return value
        value = self._while_stopped(change)
        wb = self.feature("WhiteBalanceOnce")
        if wb is not None:
            wb.available = value == "RGB8" and not self.mono
        black = self.feature("BlackLevel")
        if black is not None:
            black.max = self._black_max()
        return value

    def _set_resolution(self, value):
        i = [self._res_name(k) for k in range(len(self.resolutions))].index(value)
        self._while_stopped(lambda: self.h.put_eSize(i))
        return value

    def _set_binning(self, value):
        n = min(self._binnings(), key=lambda b: abs(b - int(value)))
        # 0x80 | n: the average of n × n pixels, so the bit depth stays.
        self._while_stopped(lambda: self.h.put_Option(self.tc.TOUPCAM_OPTION_BINNING, 1 if n == 1 else 0x80 | n))
        return n

    # ---- the region of interest, in the current resolution's pixels

    def _scale(self):
        # put_Roi takes coordinates in the full resolution's pixels.
        i = self._try(self.h.get_eSize, default=0) or 0
        full = self.resolutions[0][0]
        now = self.resolutions[min(i, len(self.resolutions) - 1)][0]
        return full / now if now else 1

    def _current_size(self):
        i = self._try(self.h.get_eSize, default=0) or 0
        return self.resolutions[min(i, len(self.resolutions) - 1)]

    def _roi(self):
        r = self._try(self.h.get_Roi, default=None)
        w, hgt = self._current_size()
        if not r or not r[2] or not r[3]:
            return (0, 0, w, hgt)
        s = self._scale()
        return (int(r[0] / s), int(r[1] / s), int(r[2] / s), int(r[3] / s))

    def _update_roi_ranges(self):
        w, hgt = self._current_size()
        for name, top in [("Width", w), ("Height", hgt), ("OffsetX", w - 8), ("OffsetY", hgt - 8)]:
            f = self.feature(name)
            if f is not None:
                f.max = top

    def _set_roi(self, x=None, y=None, width=None, height=None):
        cx, cy, cw, ch = self._roi()
        fw, fh = self._current_size()
        cw = cw if width is None else int(width)
        ch = ch if height is None else int(height)
        cx = cx if x is None else int(x)
        cy = cy if y is None else int(y)
        even = lambda v: max(0, int(v) // 2 * 2)
        cw, ch = max(8, even(min(cw, fw))), max(8, even(min(ch, fh)))
        # A larger region moves its corner in rather than being refused.
        cx, cy = even(min(cx, fw - cw)), even(min(cy, fh - ch))
        s = self._scale()
        full = (cw >= fw and ch >= fh)

        def change():
            if full:
                self.h.put_Roi(0, 0, 0, 0)
            else:
                self.h.put_Roi(even(cx * s), even(cy * s), even(cw * s), even(ch * s))
        self._while_stopped(change)
        x2, y2, w2, h2 = self._roi()
        return {"x": x2, "y": y2, "width": w2, "height": h2}[
            "width" if width is not None else "height" if height is not None else "x" if x is not None else "y"]

    # ---- exposure and trigger

    def _set_auto_exposure(self, value):
        self.h.put_AutoExpoEnable(1 if value == "Continuous" else 0)
        self.feature("ExposureTime").writable = value == "Off"
        g = self.feature("Gain")
        if g is not None:
            g.writable = value == "Off"
        return value

    def _set_trigger(self, mode=None, source=None):
        m = self.feature("TriggerMode").value if mode is None else mode
        s = self.feature("TriggerSource").value if source is None else source
        option = 0 if m == "Off" else (1 if s == "Software" else 2)
        self._while_stopped(lambda: self.h.put_Option(self.tc.TOUPCAM_OPTION_TRIGGER, option))
        self.feature("TriggerSoftware").available = m == "On" and s == "Software"
        return mode if mode is not None else source

    def execute(self, name):
        if name == "TriggerSoftware":
            self._try(self.h.Trigger, 1)
        elif name == "WhiteBalanceOnce":
            self._try(self.h.AwbOnce)

    # ---- frames

    def _bytes_per_pixel(self):
        fmt = self._fmt
        return 3 if fmt == "RGB8" else (1 if fmt.endswith("8") else 2)

    def _start_sdk(self):
        w, hgt = self._try(self.h.get_FinalSize, default=self._current_size())
        self._buffer = ctypes.create_string_buffer(max(1, w * hgt * self._bytes_per_pixel()))
        self.h.StartPullModeWithCallback(ToupTekCamera._event, self)
        self._running = True

    def _stop_sdk(self):
        self._try(self.h.Stop)
        self._running = False

    @staticmethod
    def _event(event, cam):
        # Called on ToupTek's own thread: only pull the frame here (the SDK
        # refuses settings changes from this thread).
        tc = cam.tc
        if event == tc.TOUPCAM_EVENT_IMAGE:
            info = tc.ToupcamFrameInfoV4()
            try:
                cam.h.PullImageV4(cam._buffer, 0, 24 if cam._fmt == "RGB8" else 0, -1, info)
            except Exception:
                return
            w, hgt = info.v3.width, info.v3.height
            n = w * hgt * cam._bytes_per_pixel()
            if n > len(cam._buffer):
                return      # not the size the buffer was made for: a frame from before a change
            pixels = cam._buffer.raw[:n]
            frame = (pixels, w, hgt, cam._delivered_format(pixels), int(info.v3.timestamp) * 1000)
            with cam._frame_ready:
                cam._frame = frame
                cam._frame_ready.notify()
        elif event == tc.TOUPCAM_EVENT_EXPOSURE:
            # Auto exposure moved the exposure or the gain: @Cam shows it.
            if cam.feature("ExposureAuto").value == "Continuous":
                cam.changed("ExposureTime")
                if cam.feature("Gain") is not None:
                    cam.changed("Gain")
        elif event in (tc.TOUPCAM_EVENT_DISCONNECTED, tc.TOUPCAM_EVENT_ERROR):
            cam.gone = True
            cam._running = False
            with cam._frame_ready:
                cam._frame_ready.notify()

    def _delivered_format(self, pixels):
        """The format of a frame: as chosen, except that a 10-, 12- or 14-bit
        format whose values turn out to fill all 16 bits (left-aligned) is
        sent as 16-bit, so @Cam scales it right rather than clipping it."""
        fmt = self._fmt
        if fmt[-2:] not in ("10", "12", "14"):
            return fmt
        if self._wide is None and len(pixels) >= 2:
            samples = memoryview(pixels).cast("H")[::4099]
            top = (1 << int(fmt[-2:])) - 1
            if max(samples, default=0) > top:
                self._wide = True
            elif len(samples) > 50:
                self._seen = getattr(self, "_seen", 0) + 1
                if self._seen > 20:     # twenty frames within range: right-aligned
                    self._wide = False
        return fmt[:-2] + "16" if self._wide else fmt

    def start(self):
        self._wanted = True
        if not self._running and not self.gone:
            self._start_sdk()

    def stop(self):
        self._wanted = False
        if self._running:
            self._stop_sdk()

    def grab(self):
        with self._frame_ready:
            if self._frame is None:
                self._frame_ready.wait(0.5)
            frame, self._frame = self._frame, None
        return frame


# ---------------------------------------------------------------- running it

def main():
    ap = argparse.ArgumentParser(description="Serve a ToupTek camera to @Cam.")
    ap.add_argument("--sdk", help="ToupTek's SDK folder (with python/toupcam.py and mac/libtoupcam.dylib)")
    ap.add_argument("--list", action="store_true", help="list the cameras found, and stop")
    ap.add_argument("--camera", help="which camera: its number in --list, or sn:SERIAL or name:NAME")
    ap.add_argument("--port", type=int, default=DEFAULT_PORT)
    ap.add_argument("--host", default="0.0.0.0", help="interface to listen on (0.0.0.0: all)")
    ap.add_argument("--name", default=None, help="the name shown in @Cam's camera menu")
    ap.add_argument("--no-bonjour", action="store_true", help="don't announce the bridge; add its address in @Cam")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()

    tc, lib = load_toupcam(a.sdk)
    try:
        devices = tc.Toupcam.EnumV2()
    except OSError as e:
        raise SystemExit(f"Couldn't load ToupTek's library ({e}).\n" + quarantine_hint(lib))
    if a.list:
        if not devices:
            print("No ToupTek camera found.")
        for i, d in enumerate(devices):
            print(f"{i}: {d.displayname}  (model {d.model.name}, id {d.id})")
        return
    if not devices:
        raise SystemExit("No ToupTek camera found. Check the cable, and that ToupView or another program isn't using it.")
    device = devices[0]
    if a.camera:
        if a.camera.isdigit() and int(a.camera) < len(devices):
            device = devices[int(a.camera)]
        else:
            match = [d for d in devices if a.camera in (d.id, d.displayname) or d.id.endswith(a.camera.split(":", 1)[-1])]
            if not match:
                raise SystemExit(f"No camera matches {a.camera}; see --list.")
            device = match[0]
    cam = ToupTekCamera(tc, device)
    cam.redescribe_after = {"PixelFormat", "Resolution", "BinningHorizontal", "ExposureAuto", "TriggerMode",
                            "TriggerSource", "Width", "Height", "OffsetX", "OffsetY", "BayerPattern"}
    serve(cam, host=a.host, port=a.port, name=a.name or cam.name, bonjour=not a.no_bonjour, quiet=a.quiet)


if __name__ == "__main__":
    main()
