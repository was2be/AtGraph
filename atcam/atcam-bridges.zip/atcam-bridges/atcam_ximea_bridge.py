#!/usr/bin/env python3
"""@Cam bridge for XIMEA cameras, through XIMEA's own software (xiAPI), natively
on Apple Silicon.

    python3 atcam_ximea_bridge.py
    python3 atcam_ximea_bridge.py --list
    python3 atcam_ximea_bridge.py --camera 12345678 --port 48622

Install XIMEA's macOS package first (from XIMEA; it is not part of this kit):
it puts the camera library in /Library/Frameworks and XIMEA's Python package
(ximea) into Python. If the package isn't found, --xipython takes the folder
holding it (the "ximea" folder's parent, such as XIMEA-Examples/xiPython/v3).
Needs atcam_bridge.py (this kit) beside it, and Python 3.9 or later.

What @Cam gets: the sensor's raw values (Mono or Bayer, 8 bits or the
sensor's full depth), or XIMEA's processed color, with exposure (and auto
exposure and gain), gain, resolution through downsampling, region of
interest, flips, frame rate, software and external trigger, the sensor
temperature and, on cooled models, the cooler. Controls with standard
names appear in @Cam's Camera, Image and Trigger tabs; the rest are in the
All Settings tab.
"""

import argparse
import ctypes
import os
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from atcam_bridge import Camera, Feature, serve, DEFAULT_PORT   # noqa: E402

VERSION = "atcam_ximea_bridge.py 1.0"
TIMEOUT = 10        # xiAPI's "timeout" error: no frame yet

BAYER = {"XI_CFA_BAYER_RGGB": "BayerRG", "XI_CFA_BAYER_GRBG": "BayerGR",
         "XI_CFA_BAYER_GBRG": "BayerGB", "XI_CFA_BAYER_BGGR": "BayerBG"}
MONO_DEPTHS = [8, 10, 12, 14, 16]
BAYER_DEPTHS = [8, 10, 12, 16]


def container(bits, depths):
    """The smallest listed depth that holds `bits` (11 → 12; a Bayer 14 → 16)."""
    return next((d for d in depths if d >= bits), depths[-1])


def load_xiapi(folder=None):
    if folder:
        sys.path.insert(0, os.path.expanduser(folder))
    try:
        from ximea import xiapi
        return xiapi
    except ImportError as e:
        raise SystemExit("XIMEA's Python package (ximea) wasn't found. Install XIMEA's macOS package, "
                         "or pass --xipython with the folder that holds the ximea folder "
                         f"(such as XIMEA-Examples/xiPython/v3). ({e})")
    except OSError as e:
        raise SystemExit("XIMEA's camera library couldn't be loaded; install XIMEA's macOS package "
                         f"(it puts m3api.framework in /Library/Frameworks). ({e})")


class XimeaCamera(Camera):
    vendor = "XIMEA"

    def __init__(self, xiapi, index=0, serial=None):
        super().__init__()
        self.xiapi = xiapi
        self._serial_wanted = serial
        self._index = index
        self._lock = threading.Lock()
        self._running = False
        self._errors = 0
        self.cam = None
        self._open()
        self.name = self._get("device_name", "XIMEA camera")
        self.model = self.name
        self.serial = self._get("device_sn", "")
        self._serial_wanted = self.serial or serial
        self.img = xiapi.Image()
        self._build()
        threading.Thread(target=self._watch, daemon=True).start()

    # ---- opening, and coming back after being unplugged

    def _open(self):
        cam = self.xiapi.Camera(self._index)
        try:
            if self._serial_wanted:
                cam.open_device_by_SN(self._serial_wanted)
            else:
                cam.open_device()
        except Exception as e:
            raise SystemExit(f"Couldn't open the XIMEA camera ({e}). Is CamTool or another program using it?")
        self.cam = cam

    def _watch(self):
        while True:
            time.sleep(2)
            if not self.gone:
                continue
            try:
                if self.cam is not None:
                    try:
                        self.cam.close_device()
                    except Exception:
                        pass
                self._open()
                self._apply_all()
                self._errors = 0
                self.gone = False
                print(f"[{time.strftime('%H:%M:%S')}] {self.name} is back", flush=True)
            except (SystemExit, Exception):
                pass

    def _apply_all(self):
        for name in ["PixelFormat", "BinningHorizontal", "ReverseX", "ReverseY", "ExposureAuto", "ExposureTime",
                     "Gain", "AcquisitionFrameRate", "TriggerMode"]:
            f = self.feature(name)
            if f is not None and f.available and f.on_set and f.value is not None:
                try:
                    f.on_set(f.value)
                except Exception:
                    pass

    # ---- xiAPI parameters

    def _get(self, param, default=None):
        try:
            with self._lock:
                v = self.cam.get_param(param)
            return v.decode("utf-8", "replace") if isinstance(v, bytes) else v
        except Exception:
            return default

    def _set(self, param, value):
        try:
            with self._lock:
                self.cam.set_param(param, value)
        except Exception as e:
            raise ValueError(f"The camera refused {param} = {value} ({e})")

    def _has(self, param):
        return self._get(param) is not None

    def _range(self, param, lo=None, hi=None):
        return self._get(param + ":min", lo), self._get(param + ":max", hi)

    # ---- the controls

    def _build(self):
        F = Feature
        cfa = self._get("cfa", "XI_CFA_NONE")
        self.mono = cfa not in BAYER
        self._bayer = BAYER.get(cfa, "BayerRG")
        depth = self._get("sensor_bit_depth", "XI_BPP_8")
        self._bits = int("".join(c for c in str(depth) if c.isdigit()) or 8)
        formats = [self._name(8)] + ([self._name(self._bits)] if self._bits > 8 else []) + ([] if self.mono else ["BGR8"])
        self.add(F("PixelFormat", "enum", formats[1] if len(formats) > 1 and formats[1] != "BGR8" else formats[0],
                   label="Pixel format", category="Image Format", entries=formats, on_set=self._set_format,
                   tooltip="Raw: the sensor's own values, for measuring. BGR8: XIMEA's processed color."))
        wmin, wmax = self._range("width", 8, self._get("width", 640))
        hmin, hmax = self._range("height", 8, self._get("height", 480))
        self.add(F("Width", "int", self._get("width", 0), label="Width", category="Image Format",
                   min=wmin, max=wmax, step=self._get("width:inc", 2),
                   on_set=lambda v: self._set_roi("width", v), on_get=lambda: self._get("width", 0)))
        self.add(F("Height", "int", self._get("height", 0), label="Height", category="Image Format",
                   min=hmin, max=hmax, step=self._get("height:inc", 2),
                   on_set=lambda v: self._set_roi("height", v), on_get=lambda: self._get("height", 0)))
        self.add(F("OffsetX", "int", self._get("offsetX", 0), label="Offset X", category="Image Format",
                   min=0, max=max(0, wmax - wmin), step=self._get("offsetX:inc", 2),
                   on_set=lambda v: self._set_roi("offsetX", v), on_get=lambda: self._get("offsetX", 0)))
        self.add(F("OffsetY", "int", self._get("offsetY", 0), label="Offset Y", category="Image Format",
                   min=0, max=max(0, hmax - hmin), step=self._get("offsetY:inc", 2),
                   on_set=lambda v: self._set_roi("offsetY", v), on_get=lambda: self._get("offsetY", 0)))
        dmax = self._get("downsampling:max")
        nmax = int(str(dmax).split("_")[-1].split("x")[0]) if dmax else 1
        if nmax > 1:
            self.add(F("BinningHorizontal", "int", 1, label="Downsampling", category="Image Format", min=1, max=nmax,
                       on_set=self._set_downsampling, tooltip="Combines n × n pixels into one, for speed and signal."))
            self.add(F("BinningVertical", "int", 1, label="Downsampling (vertical)", category="Image Format",
                       writable=False, on_get=lambda: self.feature("BinningHorizontal").value))
        if self._has("horizontal_flip"):
            self.add(F("ReverseX", "bool", bool(self._get("horizontal_flip", False)), label="Flip horizontally",
                       category="Image Format", on_set=lambda v: (self._set("horizontal_flip", 1 if v else 0), v)[1]))
        if self._has("vertical_flip"):
            self.add(F("ReverseY", "bool", bool(self._get("vertical_flip", False)), label="Flip vertically",
                       category="Image Format", on_set=lambda v: (self._set("vertical_flip", 1 if v else 0), v)[1]))

        emin, emax = self._range("exposure", 10.0, 1e6)
        self.add(F("ExposureAuto", "enum", "Continuous" if self._get("aeag", False) else "Off", label="Auto exposure",
                   category="Exposure", entries=["Off", "Continuous"], on_set=self._set_auto))
        self.add(F("ExposureTime", "float", float(self._get("exposure", 10000.0)), label="Exposure time",
                   category="Exposure", unit="us", min=float(emin), max=float(emax), log=True,
                   writable=not self._get("aeag", False),
                   on_set=lambda v: (self._set("exposure", float(v)), float(self._get("exposure", v)))[1],
                   on_get=lambda: float(self._get("exposure", 0.0))))
        gmin, gmax = self._range("gain")
        if gmin is not None and gmax is not None and gmax > gmin:
            self.add(F("Gain", "float", float(self._get("gain", 0.0)), label="Gain", category="Exposure", unit="dB",
                       min=float(gmin), max=float(gmax), writable=not self._get("aeag", False),
                       on_set=lambda v: (self._set("gain", float(v)), float(self._get("gain", v)))[1],
                       on_get=lambda: float(self._get("gain", 0.0))))
        fmin, fmax = self._range("framerate")
        if fmin is not None and fmax and fmax > fmin:
            self.add(F("AcquisitionFrameRate", "float", float(fmax), label="Frame rate limit", category="Acquisition",
                       unit="Hz", min=float(max(fmin, 0.1)), max=float(fmax), on_set=self._set_rate))

        trig = ["Software"] + (["Line0"] if self._has("gpi_mode") else [])
        self.add(F("TriggerMode", "enum", "Off", label="Trigger mode", category="Trigger", entries=["Off", "On"],
                   on_set=lambda v: self._set_trigger(mode=v)))
        self.add(F("TriggerSource", "enum", "Software", label="Trigger source", category="Trigger", entries=trig,
                   on_set=lambda v: self._set_trigger(source=v)))
        self.add(F("TriggerSoftware", "command", label="Software trigger", category="Trigger", available=False))

        temp = "chip_temp" if self._has("chip_temp") else "sensor_board_temp" if self._has("sensor_board_temp") else None
        if temp:
            self.add(F("DeviceTemperature", "float", 0.0, label="Sensor temperature", category="Device", unit="C",
                       writable=False, on_get=lambda: float(self._get(temp, 0.0))))
        if self._has("cooling") and self._has("target_temp"):
            tmin, tmax = self._range("target_temp", -20.0, 40.0)
            self.add(F("Cooler", "bool", self._get("cooling") != "XI_TEMP_CTRL_MODE_OFF", label="Cooler",
                       category="Cooling",
                       on_set=lambda v: (self._set("cooling", "XI_TEMP_CTRL_MODE_AUTO" if v else "XI_TEMP_CTRL_MODE_OFF"), v)[1]))
            self.add(F("CoolerTargetTemperature", "float", float(self._get("target_temp", 0.0)), label="Cooler target",
                       category="Cooling", unit="C", min=float(tmin), max=float(tmax),
                       on_set=lambda v: (self._set("target_temp", float(v)), float(self._get("target_temp", v)))[1]))
        self.add(F("WhiteBalanceAuto", "bool", False, label="Auto white balance", category="Color",
                   available=False, on_set=lambda v: (self._set("auto_wb", 1 if v else 0), v)[1]))
        pf = self.feature("PixelFormat")
        pf.value = self._set_format(pf.value)

    def _name(self, bits):
        if self.mono:
            return f"Mono{container(bits, MONO_DEPTHS)}"
        return f"{self._bayer}{container(bits, BAYER_DEPTHS)}"

    # ---- changes that need the acquisition stopped

    def _while_stopped(self, change):
        running = self._running
        if running:
            self._stop()
        try:
            return change()
        finally:
            if running:
                self._start()

    def _set_format(self, value):
        def change():
            # The format the frames are in from the restart on (the feature
            # itself takes the value only when this returns).
            self._fmt = value
            if value == "BGR8":
                self._set("imgdataformat", "XI_RGB24")
            elif value.endswith("8"):
                self._set("imgdataformat", "XI_RAW8")
            else:
                self._set("imgdataformat", "XI_RAW16")
                try:
                    self._set("output_bit_depth", f"XI_BPP_{self._bits}")
                    self._set("image_data_bit_depth", f"XI_BPP_{self._bits}")
                except ValueError:
                    pass
            return value
        value = self._while_stopped(change)
        wb = self.feature("WhiteBalanceAuto")
        if wb is not None:
            wb.available = value == "BGR8"
        return value

    def _set_downsampling(self, value):
        n = int(value)
        self._while_stopped(lambda: self._set("downsampling", f"XI_DWN_{n}x{n}"))
        self._refresh_roi()
        return n

    def _set_roi(self, param, value):
        def change():
            # A size that doesn't fit beside the corner moves the corner in rather than being refused.
            try:
                self._set(param, int(value))
            except ValueError:
                if param not in ("width", "height"):
                    raise
                self._set("offsetX" if param == "width" else "offsetY", 0)
                self._set(param, int(value))
        self._while_stopped(change)
        self._refresh_roi()
        return self._get(param, value)

    def _refresh_roi(self):
        # Width and height can reach the whole sensor (a corner in the way is
        # moved in); the offsets, as far as the region allows.
        for name, param, corner in [("Width", "width", "offsetX"), ("Height", "height", "offsetY"),
                                    ("OffsetX", "offsetX", None), ("OffsetY", "offsetY", None)]:
            f = self.feature(name)
            if f is not None:
                top = self._get(param + ":max", f.max)
                f.max = top + (self._get(corner, 0) if corner else 0)

    def _set_auto(self, value):
        self._set("aeag", 1 if value == "Continuous" else 0)
        for name in ("ExposureTime", "Gain"):
            f = self.feature(name)
            if f is not None:
                f.writable = value == "Off"
        return value

    def _set_rate(self, value):
        self._set("acq_timing_mode", "XI_ACQ_TIMING_MODE_FRAME_RATE_LIMIT")
        self._set("framerate", float(value))
        return float(self._get("framerate", value))

    def _set_trigger(self, mode=None, source=None):
        m = self.feature("TriggerMode").value if mode is None else mode
        s = self.feature("TriggerSource").value if source is None else source

        def change():
            if m == "Off":
                self._set("trigger_source", "XI_TRG_OFF")
            elif s == "Software":
                self._set("trigger_source", "XI_TRG_SOFTWARE")
            else:
                try:
                    self._set("gpi_selector", "XI_GPI_PORT1")
                    self._set("gpi_mode", "XI_GPI_TRIGGER")
                except ValueError:
                    pass
                self._set("trigger_source", "XI_TRG_EDGE_RISING")
        self._while_stopped(change)
        self.feature("TriggerSoftware").available = m == "On" and s == "Software"
        return mode if mode is not None else source

    def execute(self, name):
        if name == "TriggerSoftware":
            try:
                self._set("trigger_software", 1)
            except ValueError:
                pass

    # ---- frames

    def _start(self):
        with self._lock:
            self.cam.start_acquisition()
        self._running = True

    def _stop(self):
        try:
            with self._lock:
                self.cam.stop_acquisition()
        except Exception:
            pass
        self._running = False

    def start(self):
        if not self._running and not self.gone:
            self._start()

    def stop(self):
        if self._running:
            self._stop()

    def grab(self):
        if not self._running or self.gone:
            time.sleep(0.05)
            return None
        # Short waits, so a setting changed meanwhile doesn't wait long for the lock.
        for _ in range(5):
            try:
                with self._lock:
                    self.cam.get_image(self.img, timeout=100)
                    img = self.img
                    w, h, pad = img.width, img.height, img.padding_x
                    bpp = img.get_bytes_per_pixel()
                    data = img.get_image_data_raw()
                    saturation = img.data_saturation
                    ts = (img.tsSec * 1_000_000 + img.tsUSec) * 1000
                self._errors = 0
                break
            except self.xiapi.Xi_error as e:
                if e.status == TIMEOUT:
                    continue
                self._errors += 1
                if self._errors >= 3:
                    self.gone = True
                    self._running = False
                return None
        else:
            return None
        if pad:
            row = w * bpp
            data = b"".join(data[y * (row + pad):y * (row + pad) + row] for y in range(h))
        fmt = self._fmt
        expected = 3 if fmt == "BGR8" else (1 if fmt.endswith("8") else 2)
        if bpp != expected:
            return None     # a frame from before a change of format
        if fmt not in ("BGR8",) and not fmt.endswith("8"):
            # Deep data: name it by what the values reach (a 12-bit sensor's 0…4095 is "12").
            if saturation and saturation > (1 << int(fmt[-2:])) - 1:
                fmt = fmt[:-2] + "16"
        return data, w, h, fmt, ts


def main():
    ap = argparse.ArgumentParser(description="Serve a XIMEA camera to @Cam.")
    ap.add_argument("--xipython", help="the folder holding XIMEA's ximea Python package, if Python doesn't find it")
    ap.add_argument("--list", action="store_true", help="list the cameras found, and stop")
    ap.add_argument("--camera", help="which camera: its number in --list, or its serial number")
    ap.add_argument("--port", type=int, default=DEFAULT_PORT)
    ap.add_argument("--host", default="0.0.0.0", help="interface to listen on (0.0.0.0: all)")
    ap.add_argument("--name", default=None, help="the name shown in @Cam's camera menu")
    ap.add_argument("--no-bonjour", action="store_true", help="don't announce the bridge; add its address in @Cam")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()

    xiapi = load_xiapi(a.xipython)
    probe = xiapi.Camera()
    try:
        n = probe.get_number_devices()
    except Exception as e:
        raise SystemExit(f"XIMEA's library couldn't look for cameras ({e}).")
    if a.list:
        if n == 0:
            print("No XIMEA camera found.")
        for i in range(n):
            c = xiapi.Camera(i)
            name = c.get_device_info_string("device_name").decode("utf-8", "replace")
            sn = c.get_device_info_string("device_sn").decode("utf-8", "replace")
            print(f"{i}: {name}  (serial {sn})")
        return
    if n == 0:
        raise SystemExit("No XIMEA camera found. Check the cable, and that CamTool or another program isn't using it.")
    index, serial = 0, None
    if a.camera:
        if a.camera.isdigit() and int(a.camera) < n and len(a.camera) <= 2:
            index = int(a.camera)
        else:
            serial = a.camera
    cam = XimeaCamera(xiapi, index=index, serial=serial)
    cam.redescribe_after = {"PixelFormat", "BinningHorizontal", "ExposureAuto", "TriggerMode", "TriggerSource",
                            "Width", "Height", "OffsetX", "OffsetY"}
    serve(cam, host=a.host, port=a.port, name=a.name or cam.name, bonjour=not a.no_bonjour, quiet=a.quiet)


if __name__ == "__main__":
    main()
