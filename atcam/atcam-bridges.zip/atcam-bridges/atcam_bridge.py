#!/usr/bin/env python3
"""@Cam camera bridge: a library for serving a camera to @Cam, and a
simulated camera that runs when this file is run.

    python3 atcam_bridge.py                 # the simulated camera on port 48620
    python3 atcam_bridge.py --port 5000 --name "Bench camera"

The protocol is described in PROTOCOL.md. To bridge a real camera, subclass
Camera (see FakeCamera at the end) and call serve(). Python 3.9 or later;
numpy is optional (the simulated camera is faster and has more formats with
it). The bridge announces itself by Bonjour through macOS's dns-sd command
(or the zeroconf package, if installed); without either, add its address in
@Cam › Settings › Cameras.
"""

import argparse
import json
import math
import os
import socket
import struct
import subprocess
import sys
import threading
import time

PROTOCOL = 1
SERVICE_TYPE = "_atcam-bridge._tcp"
DEFAULT_PORT = 48620
VERSION = "atcam_bridge.py 1.0"


# ---------------------------------------------------------------- features

class Feature:
    """One control of the camera. `type` is float, int, enum, bool, command
    or string. `get` and `set` are called by the bridge; `set` returns the
    value actually applied (or raises ValueError with a message for @Cam)."""

    def __init__(self, name, type, value=None, *, label=None, category="Camera", unit="",
                 min=None, max=None, step=None, entries=None, writable=True, available=True,
                 log=False, tooltip="", on_set=None, on_get=None):
        self.name, self.type, self.value = name, type, value
        self.label, self.category, self.unit = label or name, category, unit
        self.min, self.max, self.step, self.entries = min, max, step, entries or []
        self.writable, self.available, self.log, self.tooltip = writable, available, log, tooltip
        self.on_set, self.on_get = on_set, on_get

    def describe(self):
        d = {"name": self.name, "type": self.type, "label": self.label, "category": self.category,
             "writable": self.writable, "available": self.available}
        if self.unit: d["unit"] = self.unit
        if self.tooltip: d["tooltip"] = self.tooltip
        if self.min is not None: d["min"] = self.min
        if self.max is not None: d["max"] = self.max
        if self.step is not None: d["step"] = self.step
        if self.entries: d["entries"] = self.entries
        if self.log: d["representation"] = "log"
        v = self.get()
        if v is not None: d["value"] = v
        return d

    def get(self):
        if self.on_get: self.value = self.on_get()
        return self.value

    def set(self, value):
        if not self.writable or not self.available:
            raise ValueError(f"{self.label} can't be set now")
        if self.type in ("float", "int"):
            try:
                value = float(value)
            except (TypeError, ValueError):
                raise ValueError(f"{self.label} needs a number")
            if self.min is not None: value = max(value, self.min)
            if self.max is not None: value = min(value, self.max)
            if self.type == "int":
                step = self.step or 1
                base = self.min if self.min is not None else 0
                value = int(base + round((value - base) / step) * step)
        elif self.type == "enum":
            if value not in self.entries:
                raise ValueError(f"{self.label}: no such choice '{value}'")
        elif self.type == "bool":
            value = bool(value)
        if self.on_set:
            value = self.on_set(value)
        self.value = value
        return value


class Camera:
    """What a bridge serves. Subclass it: fill `features`, and implement
    grab() to return (pixels, width, height, format, timestamp_ns) or None.
    name/vendor/model/serial describe the camera to @Cam."""
    name = "Camera"
    vendor = ""
    model = ""
    serial = ""

    def __init__(self):
        self.features = []
        self._by_name = {}

    def add(self, feature):
        self.features.append(feature)
        self._by_name[feature.name] = feature
        return feature

    def feature(self, name):
        return self._by_name.get(name)

    def start(self): pass          # frames are wanted
    def stop(self): pass           # … no longer
    def execute(self, name): pass  # a command control
    def grab(self): return None    # the next frame, blocking at the camera's rate


# ---------------------------------------------------------------- the bridge

def _pack(obj, payload=b""):
    line = json.dumps(obj, separators=(",", ":")).encode("utf-8") + b"\n"
    return struct.pack(">I", len(line) + len(payload)) + line + payload


class _Client:
    """One connected @Cam."""

    def __init__(self, bridge, sock, addr):
        self.bridge, self.sock, self.addr = bridge, sock, addr
        self.lock = threading.Lock()
        self.streaming = False
        self.alive = True

    def send(self, obj, payload=b""):
        data = _pack(obj, payload)
        with self.lock:
            try:
                self.sock.sendall(data)
            except OSError:
                self.alive = False

    def run(self):
        cam = self.bridge.camera
        frames = threading.Thread(target=self._frames, daemon=True)
        frames.start()
        buf = b""
        try:
            while self.alive:
                chunk = self.sock.recv(1 << 16)
                if not chunk:
                    break
                buf += chunk
                while len(buf) >= 4:
                    n = struct.unpack(">I", buf[:4])[0]
                    if len(buf) < 4 + n:
                        break
                    body, buf = buf[4:4 + n], buf[4 + n:]
                    line = body.split(b"\n", 1)[0]
                    try:
                        msg = json.loads(line)
                    except ValueError:
                        continue
                    self.handle(msg)
        except OSError:
            pass
        finally:
            self.alive = False
            self.streaming = False
            cam.stop()
            try:
                self.sock.close()
            except OSError:
                pass
            self.bridge.log(f"{self.addr[0]} disconnected")

    def handle(self, msg):
        cam = self.bridge.camera
        t = msg.get("type")
        if t == "hello":
            self.bridge.log(f"{msg.get('client', 'a client')} connected from {self.addr[0]}")
            self.send({"type": "welcome", "protocol": PROTOCOL, "bridge": VERSION,
                       "camera": {"name": cam.name, "vendor": cam.vendor, "model": cam.model, "serial": cam.serial},
                       "features": [f.describe() for f in cam.features]})
        elif t == "set":
            f = cam.feature(msg.get("name"))
            if f is None:
                self.send({"type": "error", "name": msg.get("name"), "message": f"No control named {msg.get('name')}"})
                return
            try:
                v = f.set(msg.get("value"))
            except ValueError as e:
                self.send({"type": "error", "name": f.name, "message": str(e)})
                return
            self.send({"type": "value", "name": f.name, "value": v})
            self.bridge.after_set(self, f)
        elif t == "get":
            f = cam.feature(msg.get("name"))
            if f is not None:
                self.send({"type": "value", "name": f.name, "value": f.get()})
        elif t == "execute":
            f = cam.feature(msg.get("name"))
            if f is not None and f.type == "command":
                cam.execute(f.name)
        elif t == "start":
            if not self.streaming:
                cam.start()
                self.streaming = True
                self.send({"type": "status", "streaming": True})
                self.bridge.log("streaming")
        elif t == "stop":
            if self.streaming:
                self.streaming = False
                cam.stop()
                self.send({"type": "status", "streaming": False})
                self.bridge.log("stopped streaming")
        elif t == "bye":
            self.alive = False

    def _frames(self):
        cam = self.bridge.camera
        frame_id = 0
        while self.alive:
            if not self.streaming:
                time.sleep(0.02)
                continue
            got = cam.grab()
            if got is None or not self.streaming:
                continue
            pixels, width, height, fmt, ts = got
            frame_id += 1
            self.send({"type": "frame", "id": frame_id, "width": width, "height": height, "format": fmt,
                       "timestamp": int(ts)}, bytes(pixels))

    def features_changed(self):
        self.send({"type": "features", "features": [f.describe() for f in self.bridge.camera.features]})


class Bridge:
    def __init__(self, camera, host="0.0.0.0", port=DEFAULT_PORT, name=None, bonjour=True, quiet=False):
        self.camera, self.host, self.port = camera, host, port
        self.name = name or camera.name
        self.bonjour, self.quiet = bonjour, quiet
        self.client = None

    def log(self, text):
        if not self.quiet:
            print(f"[{time.strftime('%H:%M:%S')}] {text}", flush=True)

    def after_set(self, client, feature):
        """Hook: a control changed. The simulated camera re-describes its
        controls when a mode change alters what else can be set."""
        if getattr(self.camera, "redescribe_after", None) and feature.name in self.camera.redescribe_after:
            client.features_changed()

    def serve(self):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((self.host, self.port))
        srv.listen(2)
        announce = _announce(self.name, self.port) if self.bonjour else None
        self.log(f"serving '{self.camera.name}' on port {self.port}"
                 + (" (announced by Bonjour)" if announce else "; add localhost:%d in @Cam › Settings › Cameras" % self.port))
        try:
            while True:
                sock, addr = srv.accept()
                sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                if self.client and self.client.alive:
                    # One client at a time.
                    sock.sendall(_pack({"type": "error", "message": "The bridge is in use by another @Cam"}))
                    sock.close()
                    continue
                self.client = _Client(self, sock, addr)
                threading.Thread(target=self.client.run, daemon=True).start()
        except KeyboardInterrupt:
            self.log("stopped")
        finally:
            if announce:
                announce()
            srv.close()


def _announce(name, port):
    """Registers the Bonjour service; returns a function that withdraws it, or None."""
    try:
        from zeroconf import ServiceInfo, Zeroconf   # pip install zeroconf
        zc = Zeroconf()
        info = ServiceInfo(SERVICE_TYPE + ".local.", f"{name}.{SERVICE_TYPE}.local.", port=port,
                           addresses=[socket.inet_aton("127.0.0.1")], server=socket.gethostname() + ".local.")
        zc.register_service(info)
        return lambda: (zc.unregister_service(info), zc.close())
    except ImportError:
        pass
    try:   # macOS: dns-sd registers the service for as long as it runs
        p = subprocess.Popen(["dns-sd", "-R", name, SERVICE_TYPE, ".", str(port)],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(0.2)
        if p.poll() is None:
            return p.terminate
    except OSError:
        pass
    return None


def serve(camera, **kw):
    Bridge(camera, **kw).serve()


# ---------------------------------------------------------------- a simulated camera

try:
    import numpy as np
except ImportError:   # pragma: no cover
    np = None


class FakeCamera(Camera):
    """A moving test pattern with the controls a real camera has: exposure
    (manual or automatic), gain, frame rate, trigger, pixel format, and a
    temperature that drifts. With numpy: Mono8, Mono12, BayerRG8 and RGB8;
    without: Mono8 only."""
    name = "Simulated camera"
    vendor = "AtGraph"
    model = "Fake"
    serial = "0001"
    width, height = 640, 480
    redescribe_after = {"ExposureAuto", "TriggerMode"}

    def __init__(self):
        super().__init__()
        self._t0 = time.monotonic()
        self._trigger = threading.Event()
        formats = ["Mono8", "Mono12", "BayerRG8", "RGB8"] if np is not None else ["Mono8"]
        self.add(Feature("Width", "int", self.width, label="Width", category="Image Format", writable=False))
        self.add(Feature("Height", "int", self.height, label="Height", category="Image Format", writable=False))
        self.add(Feature("PixelFormat", "enum", "Mono8", label="Pixel format", category="Image Format", entries=formats))
        self.add(Feature("ExposureAuto", "enum", "Off", label="Auto exposure", category="Exposure", entries=["Off", "Continuous"],
                         on_set=self._exposure_auto))
        self.add(Feature("ExposureTime", "float", 20000.0, label="Exposure time", category="Exposure", unit="us",
                         min=100.0, max=1000000.0, log=True, tooltip="Brightness scales with it, as on a real camera."))
        self.add(Feature("Gain", "float", 0.0, label="Gain", category="Exposure", unit="dB", min=0.0, max=24.0))
        self.add(Feature("AcquisitionFrameRate", "float", 20.0, label="Frame rate", category="Acquisition", unit="Hz", min=1.0, max=60.0))
        self.add(Feature("TriggerMode", "enum", "Off", label="Trigger mode", category="Trigger", entries=["Off", "On"],
                         on_set=self._trigger_mode))
        self.add(Feature("TriggerSoftware", "command", label="Software trigger", category="Trigger", available=False))
        self.add(Feature("Pattern", "enum", "Gradient", label="Pattern", category="Simulation", entries=["Gradient", "Cells"]))
        self.add(Feature("DeviceTemperature", "float", 35.0, label="Device temperature", category="Device", unit="C", writable=False,
                         on_get=lambda: round(35 + 2 * math.sin(time.monotonic() / 30), 2)))

    def _exposure_auto(self, value):
        self.feature("ExposureTime").writable = value == "Off"
        return value

    def _trigger_mode(self, value):
        self.feature("TriggerSoftware").available = value == "On"
        self._trigger.set()
        return value

    def execute(self, name):
        if name == "TriggerSoftware":
            self._trigger.set()

    def start(self):
        self._trigger.set()

    def stop(self):
        self._trigger.set()

    def grab(self):
        if self.feature("TriggerMode").value == "On":
            self._trigger.wait(0.5)
            if not self._trigger.is_set():
                return None
            self._trigger.clear()
        else:
            time.sleep(1.0 / max(self.feature("AcquisitionFrameRate").value, 0.1))
        t = time.monotonic() - self._t0
        if self.feature("ExposureAuto").value == "Continuous":
            # Settle towards the exposure that makes the pattern bright.
            f = self.feature("ExposureTime")
            f.value = f.value * 0.9 + 40000.0 * 0.1
        brightness = min(1.0, (self.feature("ExposureTime").value / 40000.0) * (10 ** (self.feature("Gain").value / 20)))
        fmt = self.feature("PixelFormat").value
        pixels = self._render(t, brightness, fmt) if np is not None else self._render_plain(t, brightness)
        return pixels, self.width, self.height, fmt if np is not None else "Mono8", int(t * 1e9)

    # The pattern: a drifting sine field, or drifting bright cells on a dark background.
    def _field(self, t):
        y, x = np.mgrid[0:self.height, 0:self.width].astype(np.float32)
        if self.feature("Pattern").value == "Cells":
            img = np.full_like(x, 0.05)
            for k in range(12):
                cx = (self.width * (0.1 + 0.8 * ((k * 0.37 + 0.1 * t) % 1.0)))
                cy = (self.height * (0.1 + 0.8 * ((k * 0.61) % 1.0)))
                img += 0.9 * np.exp(-((x - cx) ** 2 + (y - cy) ** 2) / (2 * (18 + 4 * (k % 3)) ** 2))
            return np.clip(img, 0, 1)
        return 0.5 + 0.25 * np.sin(x / 23.0 + t) * np.cos(y / 17.0 - 0.7 * t) + 0.25 * np.sin((x + y) / 41.0 + 0.3 * t)

    def _render(self, t, brightness, fmt):
        v = np.clip(self._field(t) * brightness, 0, 1)
        if fmt == "Mono8":
            return (v * 255 + 0.5).astype(np.uint8).tobytes()
        if fmt == "Mono12":
            return (v * 4095 + 0.5).astype("<u2").tobytes()
        r, g, b = v, np.clip(v * 0.7, 0, 1), np.clip(0.3 + 0.5 * v, 0, 1)    # a warm tint
        if fmt == "RGB8":
            return (np.dstack([r, g, b]) * 255 + 0.5).astype(np.uint8).tobytes()
        # BayerRG8: R at even/even, B at odd/odd, G elsewhere.
        m = np.empty((self.height, self.width), np.float32)
        m[0::2, 0::2] = r[0::2, 0::2]; m[1::2, 1::2] = b[1::2, 1::2]
        m[0::2, 1::2] = g[0::2, 1::2]; m[1::2, 0::2] = g[1::2, 0::2]
        return (m * 255 + 0.5).astype(np.uint8).tobytes()

    def _render_plain(self, t, brightness):
        # Without numpy: one precomputed sine row, shifted per row, scaled by a lookup table.
        if not hasattr(self, "_row"):
            self._row = bytes(int(127.5 + 127.5 * math.sin(x / 23.0)) for x in range(self.width * 2))
        table = bytes(min(255, int(v * brightness + 0.5)) for v in range(256))
        shift = int(t * 23) % self.width
        rows = []
        for y in range(self.height):
            s = (shift + y // 3) % self.width
            rows.append(self._row[s:s + self.width])
        return b"".join(rows).translate(table)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Serve a simulated camera to @Cam.")
    ap.add_argument("--port", type=int, default=DEFAULT_PORT)
    ap.add_argument("--host", default="0.0.0.0", help="interface to listen on (0.0.0.0: all)")
    ap.add_argument("--name", default=None, help="the name shown in @Cam's camera menu")
    ap.add_argument("--no-bonjour", action="store_true", help="don't announce the bridge; add its address in @Cam")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()
    serve(FakeCamera(), host=a.host, port=a.port, name=a.name, bonjour=not a.no_bonjour, quiet=a.quiet)
