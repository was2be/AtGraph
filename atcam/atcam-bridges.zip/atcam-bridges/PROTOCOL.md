# @Cam bridge protocol, version 1

A *bridge* is a program that drives a camera @Cam has no driver for and
serves it to @Cam over a TCP connection: the camera's controls, and its
frames. It can run on the same Mac or on another computer on the network, in
any language, linked against whatever vendor software the camera needs.
@Cam treats a bridged camera like any other: live view, calibration,
corrections, snapshots, time-lapse, movies, mosaics and two-camera views all
work unchanged.

`atcam_bridge.py` in this folder is a reference implementation in Python with
a simulated camera; it is also the easiest starting point for a real one.

## Finding a bridge

@Cam looks for bridges in two ways:

- **Bonjour.** A bridge registers the service type `_atcam-bridge._tcp` on
  the local network. @Cam lists every such service in its camera menu, under
  the service's name.
- **An address you type.** @Cam › Settings › Cameras › Camera Bridges takes
  `host:port` (for example `localhost:48620`, the reference bridge's default
  port). Bridges that don't answer are left out of the camera menu until you
  add them again or pick them from the menu.

## Transport and framing

One TCP connection per client. Every message, in both directions, is:

    4 bytes   message length N, big-endian, unsigned
    N bytes   a JSON object (UTF-8) ending with a newline (0x0A),
              then, for frames only, the pixel bytes to the end of the message

A control message is just the JSON line. A frame message is its JSON header
followed by the pixels. Keys other than the ones below are ignored, so both
sides can add fields later; an unknown `type` is ignored too.

## Messages from @Cam

| `type` | Fields | Meaning |
|---|---|---|
| `hello` | `protocol` (1), `client` | First message after connecting. |
| `set` | `name`, `value` | Set a control. `value` is a number, a string (enum entry or text) or a boolean, by the control's type. Answer with `value` (the value actually applied, which may differ) or `error`. |
| `get` | `name` | Ask for a control's current value; answer with `value`. |
| `execute` | `name` | Run a command control (a software trigger, say). |
| `start` | | Start delivering frames. |
| `stop` | | Stop delivering frames. |
| `bye` | | @Cam is closing the connection. |

## Messages from the bridge

| `type` | Fields | Meaning |
|---|---|---|
| `welcome` | `protocol` (1), `bridge`, `camera`, `features` | Reply to `hello`, within 5 seconds. `camera` is an object with `name`, `vendor`, `model`, `serial` (any may be empty). `features` describes every control (below). @Cam closes the connection, with a message, when `protocol` isn't 1. |
| `features` | `features` | The whole control list again, when it changed (a format change altered ranges, say). |
| `value` | `name`, `value` | A control's current value: after `set` or `get`, and whenever the camera changes it by itself (auto exposure, say). |
| `error` | `message`, `name` (optional) | Something failed; @Cam shows the message. |
| `frame` | `id`, `width`, `height`, `format`, `timestamp` + pixels | One frame. `id` counts up from 1. `format` is one of the names below. `timestamp` is in nanoseconds, any fixed origin (0 if unknown). |
| `status` | `streaming` | Optional: whether frames are being delivered. |

## Features

Each entry of `features` is an object:

| Key | Meaning |
|---|---|
| `name` | The control's identifier, unique. Use GenICam's standard names where the meaning matches (`ExposureTime` in µs, `Gain`, `ExposureAuto` with entries `Off`/`Continuous`, `GainAuto`, `BlackLevel`, `AcquisitionFrameRate`, `TriggerMode`, `TriggerSoftware`, `Width`, `Height`, `OffsetX`, `OffsetY`, `BinningHorizontal`, `PixelFormat`, `DeviceTemperature`): @Cam's Camera, Image and Trigger tabs show those under friendly labels, with the right units and scales. Any other name appears in the All Settings tab. |
| `type` | `float`, `int`, `enum`, `bool`, `command` or `string`. |
| `label` | What to call it (defaults to `name`). |
| `category` | A group for the All Settings tab, e.g. `Exposure`. |
| `value` | The current value. |
| `min`, `max`, `step` | Ranges for `float` and `int` (`step` for `int`). Optional: without them @Cam shows no slider and sends a typed value as it is, for the bridge to check. Widths, heights and ranges must fit the camera; @Cam ignores a frame whose width or height isn't a whole number from 1 to 65,536. |
| `entries` | The choices of an `enum`, as strings. |
| `unit` | A unit label, e.g. `us`, `dB`, `K`. |
| `writable` | Whether it can be set now (default true). A control under an automatic mode should say false while that mode is on, and send `features` or a `value` when it changes. |
| `available` | Whether it exists now (default true). |
| `representation` | `log` for a logarithmic slider (exposure times), else `linear`. |
| `tooltip` | Help text. |

## Frame formats

`format` names follow GenICam. Pixels are row-major with no padding;
multi-byte samples are little-endian.

| Name | Bytes per pixel | Notes |
|---|---|---|
| `Mono8` | 1 | |
| `Mono10`, `Mono12`, `Mono14`, `Mono16` | 2 | Right-aligned in 16 bits. |
| `BayerRG8`, `BayerGR8`, `BayerGB8`, `BayerBG8` | 1 | Debayered in @Cam to 8-bit color. |
| `BayerRG12` … (also `10`, `16`) | 2 | Likewise. |
| `RGB8`, `BGR8` | 3 | 8-bit color. |
| `BGRA8` | 4 | 8-bit color with an unused fourth byte, @Cam's own layout. |

## Behavior

- Send frames only between `start` and `stop`, at the camera's rate. @Cam
  keeps the newest frame and drops the rest when it falls behind, so there is
  no need to throttle.
- Answer every `set` with a `value` or an `error`. @Cam shows the value it
  gets back, so the camera's rounding is visible. After an `error` naming the
  control, @Cam shows the value from before the `set` and sends a `get`.
- If the camera disappears, close the connection; @Cam reports the camera as
  disconnected and offers it again when the bridge is back.
- A bridge may serve one client at a time; refuse or queue a second.

## Example exchange

    → {"type":"hello","protocol":1,"client":"@Cam 0.8"}
    ← {"type":"welcome","protocol":1,"bridge":"atcam_bridge.py 1.0",
       "camera":{"name":"Fake camera","vendor":"AtGraph","model":"Fake","serial":"0001"},
       "features":[{"name":"ExposureTime","type":"float","label":"Exposure time","unit":"us",
                    "min":100,"max":1000000,"value":20000,"representation":"log","category":"Exposure"}, …]}
    → {"type":"set","name":"ExposureTime","value":50000}
    ← {"type":"value","name":"ExposureTime","value":50000}
    → {"type":"start"}
    ← {"type":"frame","id":1,"width":640,"height":480,"format":"Mono8","timestamp":0}<307200 bytes>
    ← {"type":"frame","id":2, …}
    → {"type":"stop"}
    → {"type":"bye"}
